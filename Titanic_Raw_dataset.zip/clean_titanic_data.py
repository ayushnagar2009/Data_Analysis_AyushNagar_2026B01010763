import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

def clean_titanic_dataset(input_file, output_file):
    # Load dataset
    xls = pd.ExcelFile(input_file)
    df = pd.read_excel(input_file, sheet_name=xls.sheet_names[0])

    # 1. Clean Missing Values
    df_clean = df.copy()
    df_clean['age'] = df_clean.groupby(['pclass', 'sex'])['age'].transform(lambda x: x.fillna(x.median()))
    df_clean['embarked'] = df_clean['embarked'].fillna(df_clean['embarked'].mode()[0])
    df_clean['fare'] = df_clean['fare'].fillna(df_clean['fare'].median())
    df_clean['cabin'] = df_clean['cabin'].fillna('Unknown')
    df_clean['boat'] = df_clean['boat'].fillna('None')
    df_clean['body'] = df_clean['body'].fillna(-1)
    df_clean['home.dest'] = df_clean['home.dest'].fillna('Unknown')

    # 2. Setup Excel Workbook & Formatting
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Cleaned Titanic Data"

    headers = list(df_clean.columns)
    ws.append(headers)

    header_fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
    header_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    data_font = Font(name="Calibri", size=10)
    thin_border = Border(
        left=Side(style='thin', color='D3D3D3'),
        right=Side(style='thin', color='D3D3D3'),
        top=Side(style='thin', color='D3D3D3'),
        bottom=Side(style='thin', color='D3D3D3')
    )
    zebra_fill = PatternFill(start_color="F9FAFB", end_color="F9FAFB", fill_type="solid")

    # Format Header Row
    for col_num, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_num)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    # Format Data Rows
    for row_idx, row_data in enumerate(df_clean.values, start=2):
        ws.append(list(row_data))
        for col_idx in range(1, len(headers) + 1):
            cell = ws.cell(row=row_idx, column=col_idx)
            cell.font = data_font
            cell.border = thin_border
            if row_idx % 2 == 0:
                cell.fill = zebra_fill
            
            # Alignments & Number Formats
            val = cell.value
            if isinstance(val, (int, float)):
                if col_idx in [1, 2, 6, 7]: # pclass, survived, sibsp, parch
                    cell.alignment = Alignment(horizontal="center", vertical="center")
                elif col_idx == 9: # fare
                    cell.number_format = '#,##0.00'
                    cell.alignment = Alignment(horizontal="right", vertical="center")
                elif col_idx == 5: # age
                    cell.number_format = '0.##'
                    cell.alignment = Alignment(horizontal="right", vertical="center")
                else:
                    cell.alignment = Alignment(horizontal="right", vertical="center")
            else:
                cell.alignment = Alignment(horizontal="left", vertical="center")

    # Auto-adjust column widths with extra padding so text never overlaps
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            val_str = str(cell.value or '')
            if len(val_str) > max_len:
                max_len = len(val_str)
        ws.column_dimensions[col_letter].width = max(max_len + 5, 12)

    # Freeze Header Row
    ws.freeze_panes = 'A2'

    # Save Cleaned Workbook
    wb.save(output_file)
    print(f"Data successfully cleaned and saved to: {output_file}")

if __name__ == "__main__":
    clean_titanic_dataset("Titanic Dataset.xlsx", "Cleaned_Titanic_Data.xlsx")
